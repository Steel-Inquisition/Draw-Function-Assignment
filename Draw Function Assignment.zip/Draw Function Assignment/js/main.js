//Graphics Libary
let cnv = document.getElementById("my-canvas");
let ctx = cnv.getContext("2d");

cnv.width = 800;
cnv.height = 600;

function drawArt(x, y, x1, y1, x2, y2, x3, y3) {
    circle(x + 200, y + 180, 50, "stroke"); // large circle
    circle(x + 200, y + 180, 20, "stroke"); // small circle
    triangle(x1 + 250, y1 + 130, x2 + 250, y2 + 230, x3 + 350, y3 + 180, "stroke"); // Right Triangle
    triangle(x1 + 150, y1 + 130, x2 + 150, y2 + 230, x3 + 50, y3 + 180, "stroke"); // Left Triangle
    triangle(x1 + 150, y1 + 130, x2 + 250, y2 + 130, x3 + 200, y3 + 30, "stroke"); // Up Triangle
    triangle(x1 + 150, y1 + 230, x2 + 250, y2 + 230, x3 + 200, y3 + 325, "stroke"); // Down Triangle
}

drawArt(0, 0, 0, 0, 0, 0, 0, 0);