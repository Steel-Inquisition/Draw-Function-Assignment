function stroke(color) {
    ctx.strokeStyle = color;
}

function stroke(style) {
    ctx.strokeStyle = style;
}

function fill(style) {
    ctx.fillStyle = style;
}

function lineWidth(width) {
    ctx.lineWidth = width;
}

function font(fontSettng) {
    ctx.font = fontSettng;
}

// Draw a circle with a center (x,y) and radius of r
function circle(x, y, r, mode) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 2 * Math.PI);

    if (mode == "fill") {
        ctx.fill();
    } else if (mode == "stroke") {
        ctx.stroke();
    }
}

function triangle(x1, y1, x2, y2, x3, y3, mode) {
    ctx.beginPath();
    ctx.moveTo(x1, y1); // Vertex 1
    ctx.lineTo(x2, y2); // Vertex 2
    ctx.lineTo(x3, y3); // Vertex 3

    if (mode == "fill") {
        ctx.fill();
    } else if (mode == "stroke") {
        ctx.closePath();
        ctx.stroke();
    }

    ctx.stroke();
}